package com.nico.store.store.form;

public class UserProfileForm {

}
